﻿using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;

using UnityEngine;
using UnityEngine.UI;
using Random = System.Random;

public class GameManager : MonoBehaviour
{
    #region 変数

    public int mineNumber;
    //行列
    public int row;
    public int column;
    /// <summary>
    /// 列行 0,1表示1行2列
    /// (0,0) (0,1) (0,2) (0,3)
    /// (1,0) (1,1) (1,2) (1,3) 
    /// </summary>

    public GameObject prefabToSpawn; // 指定要生成的预制体

    public Transform cellLayoutGroup; // 指定目标物体的Transform

    public GameObject gameOverText;
    public GameObject gamewinText;

    public bool GameOver;

    public bool youWin;

    bool[,] visited; // 用于跟踪已经探索过的格子
    GameObject[,] cellModelList;
    /// <summary>
    /// 一个存放物体的数据结构 -1是炸弹 扫雷
    /// </summary>
    int[,] cellNumberList;
    //一个存放物体 物体的显示是根据数据来的
    /// <summary>
    /// 注意是y,x
    /// </summary>
    public  CellManager[,] cellList;


    public static GameManager instance;

    public List<CellManager> restCellManagers;

    #endregion

    void Awake()
    {
        instance = this;


    }

    void Start()
    {
        CreateCell();
        GameStart();
    }

    #region ゲーム初期化

        public void CreateCell()
    {
        cellModelList = new GameObject[row,column];
        for (int y = 0; y < column; y++)
        {
            for (int x = 0; x < row; x++)
            {
                GameObject cell = Instantiate(prefabToSpawn, cellLayoutGroup);
                cellModelList[x, y] = cell;
            }
        }
    }

    public void Init()
    {
        GameOver = false;
        youWin = false;
        foreach (var VARIABLE in cellModelList)
        {
            VARIABLE.GetComponent<SingleCellDisplay>().Init();
        }
        
        gameOverText.SetActive(false);
        gamewinText.SetActive(false);
        AIManager.instance.Init();
        restCellManagers = new List<CellManager>();
        
    }
    public void GameStart()
    {
        Init();


        
        cellNumberList =new int[row,column];
        cellList =new CellManager[row,column];
        visited = new bool[row, column];

        DecideBoom(mineNumber, 0, row-1);
        calculateNumber();
        for (int y = 0; y < column; y++)
        {
            for (int x = 0; x < row; x++)
            {
                GameObject cell = cellModelList[y, x];
                CellManager cellManager = new CellManager();
                cellManager.boomNumber =  cellNumberList[y, x];
                cellManager.isBoom = false;
                if (cellNumberList[y, x] != -1)
                {
                    cellManager.isBoom = false;
                }
                else
                {
                    cellManager.isBoom = true;
                }
                
                cell.GetComponent<SingleCellDisplay>().cellManager = cellManager;
                
                cellManager.position =new Tuple<int, int>(y, x);

                cellManager.cellModel = cell;
                cellList[y, x] = cellManager;
                int cellNumber = cellNumberList[y, x];
                if (cellNumber == -1)
                {
                    cell.GetComponent<SingleCellDisplay>().SetBomb();
                }
                else
                {
                    cell.GetComponent<SingleCellDisplay>().SetNumber(cellNumber);
                }
            }
        }

        foreach (var VARIABLE in cellList)
        {
            restCellManagers.Add(VARIABLE);
        }
        
        AIManager.instance.cellList = cellList;
    }

    public void DecideBoom(int n, int min, int max)
    {
        List<Tuple<int, int>> resultList = GenerateRandomTuples(n, min, max);
        /*Debug.Log("bomb number is"+resultList.Count);*/
        foreach(Tuple<int, int>bombPosition in resultList)
        {
            //爆弾なら-1
            cellNumberList[bombPosition.Item1, bombPosition.Item2] = -1;

        }
    }
    public void calculateNumber()
    {

        for (int row = 0; row < cellNumberList.GetLength(0); row++)
        {
            for (int col = 0; col < cellNumberList.GetLength(1); col++)
            {
                // 如果当前单元格不是炸弹（值不为-1），则计算相邻炸弹数量
                if (cellNumberList[row, col] != -1)
                {
                    int bombCount = 0; // 相邻炸弹数量

                    // 遍历当前单元格周围的8个相邻单元格
                    for (int i = -1; i <= 1; i++)
                    {
                        for (int j = -1; j <= 1; j++)
                        {
                            int neighborRow = row + i;
                            int neighborCol = col + j;

                            // 检查边界条件，确保不越界
                            if (neighborRow >= 0 && neighborRow < cellNumberList.GetLength(0) &&
                                neighborCol >= 0 && neighborCol < cellNumberList.GetLength(1))
                            {
                                // 如果相邻单元格是炸弹，增加相邻炸弹数量
                                if (cellNumberList[neighborRow, neighborCol] == -1)
                                {
                                    bombCount++;
                                }
                            }
                        }
                    }

                    // 将计算的相邻炸弹数量设置到当前单元格
                    cellNumberList[row, col] = bombCount;
                }
            }
        }

    }

    private List<Tuple<int, int>> GenerateRandomTuples(int n, int min, int max)
    {
        List<Tuple<int, int>> result = new List<Tuple<int, int>>();
        Random random = new Random();

        while (result.Count < n)
        {
            int number1 = random.Next(min, max + 1);
            int number2 = random.Next(min, max + 1);

            Tuple<int, int> newTuple = new Tuple<int, int>(number1, number2);

            // 检查是否已经存在相同的2元数组
            bool isDuplicate = false;
            foreach (var existingTuple in result)
            {
                if (existingTuple.Item1 == newTuple.Item1 && existingTuple.Item2 == newTuple.Item2)
                {
                    isDuplicate = true;
                    break;
                }
            }

            // 如果不是重复的，添加到结果列表
            if (!isDuplicate)
            {
                result.Add(newTuple);
            }
        }

        return result;
    }

    // Update is called once per frame
    void Update()
    {
        if (!GameOver)
        {
            // 如果用户按下鼠标左键
            if (Input.GetMouseButtonDown(0))
            {
                GameObject targetObject = GetClickedTarget();
                if (targetObject!=null)
                {
                    if (targetObject.GetComponent<SingleCellDisplay>().cellManager.isFlaged == false
                        && targetObject.GetComponent<SingleCellDisplay>().cellManager.isOpen == false
                        )
                    {
                        Debug.Log("你点击的坐标是"+targetObject.GetComponent<SingleCellDisplay>().cellManager.position.Item2+" "+targetObject.GetComponent<SingleCellDisplay>().cellManager.position.Item1);
                        ExploreEvent(targetObject);
                    } 
                }
            }
            else if (Input.GetMouseButtonDown(1))
            {
                GameObject targetObject = GetClickedTarget();
                if (targetObject!=null)
                {

                    SetFlage(targetObject); 
                }
            } 
        }
    }

    private static GameObject GetClickedTarget()
    {
        Debug.Log("玩家开始点击");
        RaycastHit2D hit = Physics2D.Raycast(Input.mousePosition, Vector2.zero);
        //点击对象是主战者,随从,还是卡牌？
        if (hit.collider != null)
        {
            Debug.Log("clickobkect");
            return hit.transform.gameObject;
            // 检测到碰撞，获取被射线碰撞到的物体
        }else return null;


    }

    public void SetFlage(GameObject targetObject)
    {
        SingleCellDisplay singleCellDisplay=targetObject.GetComponent<SingleCellDisplay>();
        if (singleCellDisplay != null)
        {
            if(singleCellDisplay.cellManager.isFlaged==false && singleCellDisplay.cellManager.isOpen==false)
            {
                singleCellDisplay.cellManager.isFlaged = true;
                singleCellDisplay.SetFlag();
            }
            else
            {
                singleCellDisplay.cellManager.isFlaged = false;
                singleCellDisplay.CloseFlag();
            }
        }
        CheckGameFinishedAndFinishGame();
    }

    #endregion


    #region セル探索

        public void Explore(int y, int x)
    {
        // 检查坐标是否越界或已经探索过
        if (y < 0 || y >= row || x < 0 || x >=column  || visited[y, x])
            return;
        
        // 标记当前格子为已访问
        visited[y,x] = true;
        SingleCellDisplay myScript=cellList[y, x].cellModel.GetComponent<SingleCellDisplay>();
        myScript.cellManager.isOpen = true;
        myScript.ShowCell();
        if (myScript.cellManager.isFlaged == true)
        {
            myScript.cellManager.isFlaged=false;
            myScript.CloseFlag();
        }

        if (restCellManagers.Contains(cellList[y, x]))
        {
            restCellManagers.Remove(cellList[y, x]);
        }
        tempExploredCell.Add((cellList[y, x]));
        // 如果当前格子是0，递归探索相邻的8个格子
        if (cellNumberList[y, x] == 0)
        {
            Explore(y - 1, x - 1);
            Explore(y - 1, x);
            Explore(y - 1, x + 1);
            Explore(y, x - 1);
            Explore(y, x + 1);
            Explore(y + 1, x - 1);
            Explore(y + 1, x);
            Explore(y + 1, x + 1);
        }

    }

    //记录每次探索的cell
    List<CellManager> tempExploredCell;
    public void ExploreEvent(GameObject targetObject)
    {
        /*Debug.Log("开始探索周围");*/
        visited = new bool[row,column];
        
        tempExploredCell = new List<CellManager>();
        // 获取目标物体上的脚本（假设这个脚本是 MyScript）
        SingleCellDisplay myScript = targetObject.GetComponent<SingleCellDisplay>();

        // 如果找到了脚本
        if (myScript != null)
        {
            /*Debug.Log("clickobkect");*/
            // 激活脚本
            Tuple<int, int> cellPosition = myScript.cellManager.position;
            Explore(cellPosition.Item1,cellPosition.Item2);

            /*Debug.Log(myScript.cellManager.boomNumber);*/
            if (myScript.cellManager.boomNumber == -1)
            {
                /*Debug.Log("gameover");*/
                youWin = false;
                gameOverText.SetActive(true);
                
                GameOver = true;
            }
            CheckGameFinishedAndFinishGame();
        }

        //加上ai自动部分
        AIManager.instance.CalculateAllProb();
        
    }

    #endregion


    #region ゲーム終了判定
    public bool CheckGameFinished()
    {
        foreach(CellManager cell in cellList)
        {
            if (cell.isOpen ==false && cell.isFlaged ==false)
            {
                return false;
            }
            if (cell.isFlaged == true)
            {
                if (cell.boomNumber!=-1)
                {
                    return false;
                }
            }
        }
        return true;
    }

    public bool dontFinishGame;
    public void CheckGameFinishedAndFinishGame()
    {
        if (!dontFinishGame)
        {
            if (CheckGameFinished())
            {
                youWin = true;
                gamewinText.SetActive(true);
                GameOver = true;
            }
        }
    }

    

    #endregion

}
