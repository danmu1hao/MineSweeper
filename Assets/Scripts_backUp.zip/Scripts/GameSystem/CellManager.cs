using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellManager
{
    public GameObject cellModel;
    //isBoom=>1
    public bool isBoom;


    public float weight;
    
    /// <summary>
    /// 这个是为了标记周围格子
    /// 我们要把未知格子进行分类的
    /// </summary>
    public bool isSurrondCell;

    private float probobability;
    public float Probobability
    {
        get
        {
            return (float)Math.Round(probobability, 3);
        }
        set
        {
            probobability=value;
        }
    }

    public bool isOpen=false;
    
    public int boomNumber;
    /// <summary>
    /// (y,x)
    /// </summary>
    public Tuple<int, int> position;
    public bool isFlaged;
    
    
    public List<CellManager> nearbyCell;

    /// <summary>
    /// 这个标识周围的未知格子，注意是未知，不是相邻
    /// </summary>
    public int nearbyUnknownCell=0;

    public float PSEQ_Q;
    public float PSEQ_S=0;

    public int index;
    public CellGroup cellGroup;
}
