using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Calculate : MonoBehaviour
{
    List<Tuple<List<CellManager>, int>> cellEquation;
    
    // Start is called before the first frame update
    void Start()
    {
        /*CellManager cell1=new CellManager();
        CellManager cell2= new CellManager();
        CellManager cell3= new CellManager();
        CellManager cell4= new CellManager();
        CellManager cell5= new CellManager();
        // 示例的 cellEquation 数据
        cellEquation = new List<Tuple<List<CellManager>, int>>
        {
            Tuple.Create(new List<CellManager> {
                cell1,cell2,cell3,cell4
            }, 4),
            Tuple.Create(new List<CellManager> {
                cell2,cell3,cell4,cell5
            }, 4),
            Tuple.Create(new List<CellManager> {
                cell1,cell2,cell3,cell5
            }, 4),
            Tuple.Create(new List<CellManager> {
                cell1,cell2,cell5,cell4
            }, 4)
            
        };
        // 第一步：生成 allCellManager 列表，并为每个 SingleCellManager 分配索引
        List<CellManager> allCellManager = GenerateAllCellManager(cellEquation);

        // 第二步：将 cellEquation 转换为矩阵形式
        int[,] matrix = ConvertToMatrix(cellEquation, allCellManager);

        // 输出矩阵
        PrintMatrix(matrix);*/
    }

    // 生成不重复的 allCellManager 列表，并为每个 CellManager 分配索引
    public static List<CellManager> GenerateAllCellManager(List<Tuple<List<CellManager>, int>> cellEquation)
    {
        List<CellManager> allCellManager = new List<CellManager>();
        Dictionary<CellManager, int> cellDict = new Dictionary<CellManager, int>();

        foreach (var equation in cellEquation)
        {
            foreach (var cell in equation.Item1)
            {
                // 如果字典中没有此cell，就添加到allCellManager并给它分配index
                if (!cellDict.ContainsKey(cell))
                {
                    cell.index = allCellManager.Count;  // 设置索引
                    allCellManager.Add(cell);  // 加入allCellManager列表
                    cellDict[cell] = cell.index;  // 存入字典，避免重复
                }
                else
                {
                    // 更新cell的索引为已存在的index
                    cell.index = cellDict[cell];
                }
            }
        }

        return allCellManager;
    }
    // 将 cellEquation 转换为矩阵
    public static int[,] ConvertToMatrix(List<Tuple<List<CellManager>, int>> cellEquation, List<CellManager> allCellManager)
    {
        int rows = cellEquation.Count;
        int cols = allCellManager.Count + 1;  // 列数为cell数量加1（用于存储常数项）

        int[,] matrix = new int[rows, cols];

        for (int i = 0; i < rows; i++)
        {
            var equation = cellEquation[i];

            // 遍历左边的 cell 列表
            foreach (var cell in equation.Item1)
            {
                matrix[i, cell.index] = 1;  // 在对应的列设置为1
            }

            // 设置常数项（方程右边的值）
            matrix[i, cols - 1] = equation.Item2;
        }

        return matrix;
    }

    // 打印矩阵


    public static void PrintMatrix(int[,] matrix)
    {
        int rows = matrix.GetLength(0);
        int cols = matrix.GetLength(1);

        for (int i = 0; i < rows; i++)
        {
            string row = "";  // 用于拼接一行的数据
            for (int j = 0; j < cols; j++)
            {
                row += $"{matrix[i, j]} ";  // 将每个元素添加到行
            }
            Debug.Log(row);  // 输出完整的一行
        }
    }

}
