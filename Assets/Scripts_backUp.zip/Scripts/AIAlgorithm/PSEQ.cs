using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class PSEQ : MonoBehaviour
{
    #region 変数

    public static List<int[]> solutions;
    public static List<CellManager> allSurrondCellManager;

    #endregion


    #region PSEQ_Logic
    //p=a/b a:マインである回数　b:総回数
    void FILTER_P()
    {
        
    }
    //p(b, n)χ(C − {b} − (∪S(b, n)))
        public static List<CellManager> FILTER_S(List<CellManager> cells)
    {
        //放弃分区的思路？
        List<CellGroup> cellGroups=new List<CellGroup>();
        foreach (var cellManager in AIManager.instance.surroundCell)
        {
            if (!cellGroups.Contains(cellManager.cellGroup) && cellManager.cellGroup!=null)
            {
                cellGroups.Add(cellManager.cellGroup);
            }
        }
        CellGroup cellGroup=new CellGroup();
        cellGroup=MergeCellGroup(cellGroups);

        //周围有有情报的吗？
        List<CellManager> near=new List<CellManager>();
        List<CellManager> others=new List<CellManager>();

        
        bool success=false;
        foreach (var cell in cells)
        {
            success = false;
            foreach (var nearbyCell in AIManager.instance.ExploreSurroundings(new List<CellManager>(){cell}))
            {
                if (AIManager.instance.surroundCell.Contains(nearbyCell))
                {
                    near.Add(cell);
                    success = true;
                }
            }
            if (!success)
            {
                others.Add(cell);
            }

        }
        /*Debug.Log("near"+near.Count+"others"+others.Count());*/
        //near, other
        //other简单

        #region near
        //两个字典 一个用来统计概率·，一个用来看每个情况有多少个安全格子
        Dictionary<int, int> oneAppearTimesDict = new Dictionary<int, int>();
        Dictionary<int, List<CellManager>> oneAppearTimesAndSafeCellListDict = new Dictionary<int, List<CellManager>>();

        
        //真正重要的是near的周围一圈
        foreach (var nearCellManager in near)
        {
            List<CellManager> haveDataCellManager=new List<CellManager>();
            List<CellManager> surrondCellManagers = AIManager.instance.ExploreSurroundings(near);
            foreach (var cellManager in surrondCellManagers)
            {
                if (AIManager.instance.surroundCell.Contains(cellManager))
                {
                    haveDataCellManager.Add(cellManager);
                }
            }
            Tuple<Dictionary<int, int>,Dictionary<int, List<CellManager>>>  tuple=PSEQ_S_Caculate(cellGroup,haveDataCellManager);
            oneAppearTimesDict = tuple.Item1;
            oneAppearTimesAndSafeCellListDict = tuple.Item2;
            // 计算总和
            int totalValue = 0;
            foreach (var pair in oneAppearTimesDict)
            {
                totalValue += pair.Value;
            }
            /*Debug.Log("一共有多少种可能"+totalValue);*/
            float PSEQ_S = 0;
            for (int i = 0; i <= 8; i++)
            {
                if (oneAppearTimesDict.ContainsKey(i))
                {
                    if (oneAppearTimesAndSafeCellListDict.ContainsKey(i))
                    {
                        float prob=(float)oneAppearTimesDict[i]/totalValue;
                        PSEQ_S+=prob*oneAppearTimesAndSafeCellListDict[i].Count;
                        if (prob*oneAppearTimesAndSafeCellListDict[i].Count>0)
                        {
                            /*
                            Debug.Log(prob+"概率和安全格子为 "+oneAppearTimesAndSafeCellListDict[i].Count+"PSEQ当前为"+PSEQ_S);
                        */
                        }
                    }
                }
            }
            nearCellManager.PSEQ_S = PSEQ_S;
            if (PSEQ_S>0)
            {
                /*Debug.Log("我们算出"+nearCellManager.PSEQ_S);*/
            }
        }


        #endregion
                
        
        #region other

        if (others.Count!=0)
        {
            foreach (var cell in others)
            {
                cell.nearbyUnknownCell = AIManager.instance.GetSurroundingCount(cell);

                //我们只关心自己为0的可能
            }

            others=others.OrderBy(cell => cell.nearbyUnknownCell).ToList();
            // 获取最小值
            int minValue = others.First().nearbyUnknownCell;

            // 筛选出所有具有最小值的元素
            var minElements = others.Where(cell => cell.nearbyUnknownCell == minValue).ToList();
            float otherProb = AIManager.instance.otherProb;
            /*Debug.Log(otherProb);*/
            //概率为全部为安全
            /*Debug.Log("最小邻接数"+minValue);*/
            float prob_other=1;
            for (int i = 0; i < minValue; i++)
            {
                prob_other*=1-otherProb;
            }

            foreach (var cellManager in minElements)
            {
                cellManager.PSEQ_S = prob_other*minValue;
            }
            /*Debug.Log("其他的PSEQ为"+prob_other+" "+minValue);*/
        }
        //这一圈在外面的一圈


        #endregion

        // 找到 PSEQ_S 最大值
        float maxPSEQ_S = cells.Max(cell => cell.PSEQ_S);

        // 找到所有 PSEQ_S 等于最大值的元素
        var maxCells = cells.Where(cell => Mathf.Approximately(cell.PSEQ_S, maxPSEQ_S)).ToList();

        if (AIManager.instance.debugMode)
        {
            Debug.Log("我们最终有这么多格子: " + maxCells.Count);
        }

        return maxCells;
    }
    static Tuple<Dictionary<int, int>,Dictionary<int, List<CellManager>>> PSEQ_S_Caculate(CellGroup cellGroup,List<CellManager> cellList)
    {
                  
            //两个字典 一个用来统计概率·，一个用来看每个情况有多少个安全格子
            Dictionary<int, int> oneAppearTimesDict = new Dictionary<int, int>();
            Dictionary<int, List<CellManager>> oneAppearTimesAndSafeCellListDict = new Dictionary<int, List<CellManager>>();
            //接下来就是找solution的排列
            //首先根据数值来筛选对应的solution
            List<int> nearCellIndex=new List<int>();
            
            foreach (var cellManager in cellList)
            {
                cellManager.index = cellGroup.cellManagers.IndexOf(cellManager);
                /*Debug.Log("这个的index是"+cellManager.index+"长度为"+cellGroup.cellManagers.Count);*/
                nearCellIndex.Add(cellManager.index);
            }

            if (cellGroup.solutions==null)
            {
                /*Debug.LogWarning("似乎solution为空");*/
            }
            //有两个要关注的 1：概率 2：安全格子
            /*Debug.Log("一共有多少种solution"+cellGroup.solutions.Count);*/
            foreach (var solution in cellGroup.solutions)
            {
                int oneAppearTimes= 0;
                //1 概率
                foreach (var index in nearCellIndex)
                {
                    oneAppearTimes += solution[index];
                }
                if (oneAppearTimesDict.ContainsKey(oneAppearTimes))
                {
                    oneAppearTimesDict[oneAppearTimes] += 1;
                }
                else
                {
                    oneAppearTimesDict.Add(oneAppearTimes,1);
                }
                //2:安全格子
                if (oneAppearTimesAndSafeCellListDict.ContainsKey(oneAppearTimes))
                {
                    var originalList = oneAppearTimesAndSafeCellListDict[oneAppearTimes];
                    foreach (var cellManagerTemp in originalList.ToList()) // 使用副本遍历
                    {
                        //如果部位0，那么排除掉
                        if (solution[cellManagerTemp.index] != 0)
                        {
                            originalList.Remove(cellManagerTemp); // 修改原集合
                        }
                    }
                }
                else
                {
                    List<CellManager> cellManagers = new List<CellManager>();
                    for (int i = 0; i < solution.Length; i++)
                    {
                        if (solution[i]==0)
                        {
                            cellManagers.Add(cellGroup.cellManagers[i]);
                        }
                    }
                    oneAppearTimesAndSafeCellListDict.Add(oneAppearTimes,cellManagers);
                }
            }

            foreach (var VARIABLE in oneAppearTimesAndSafeCellListDict)
            {
                if (VARIABLE.Value.Count>0)
                {
                    /*Debug.Log("对于数字"+VARIABLE.Key+"还剩下几个确定安全的格子？"+VARIABLE.Value.Count);*/
                }
            }

            return new Tuple<Dictionary<int, int>, Dictionary<int, List<CellManager>>>(oneAppearTimesDict,
                oneAppearTimesAndSafeCellListDict);
    }
   
    
    void FILTER_E()
    {
        
    }
    public static float FILTER_Q(CellManager targetCell)
    {
        float result=0;
        foreach (float prob in FILTER_Prob(targetCell))
        {

            if (prob>0)
            {
                double temp = prob * Math.Log(prob, 2)*-1;
                result += (float)temp;
            }
        }
        
        result=(float)Math.Round(result, 3);
        return result;
    }
    
    //放弃分区，先简单的合并吧
    public static CellGroup MergeCellGroup(List<CellGroup> cellGroups)
    {
        if (cellGroups == null || cellGroups.Count == 0)
        {
            /*Debug.LogWarning("bug");*/
            return null; // 如果没有需要合并的 CellGroup，直接返回
        }
        
        
        
        // 创建一个新的合并结果 CellGroup
        CellGroup mergedGroup = new CellGroup();

        // 合并 cellManagers
        foreach (var cellGroup in cellGroups)
        {
            if (cellGroup!=null)
            {

                mergedGroup.cellManagers.AddRange(cellGroup.cellManagers);
            }
            else
            {
                /*Debug.LogWarning("bug!!!!");*/
            }

        }

        // 合并 solutions
        var mergedSolutions = MergeSolutions(cellGroups);
        mergedGroup.solutions = mergedSolutions;

        // 打印合并结果（调试用）
        /*Debug.Log($"Merged cellManagers count: {mergedGroup.cellManagers.Count}");
        Debug.Log($"Merged solutions count: {mergedGroup.solutions.Count}");*/
        return mergedGroup;
    }
    static List<int[]> MergeSolutions(List<CellGroup> cellGroups)
    {
        if (cellGroups == null || cellGroups.Count == 0)
        {
            return new List<int[]>(); // 如果没有 CellGroup，返回空列表
        }

        return MergeRecursive(cellGroups, 0);
    }
    private static List<int[]> MergeRecursive(List<CellGroup> cellGroups, int index)
    {
        if (index == cellGroups.Count - 1) 
        {
            // 递归到最后一个 CellGroup 时，直接返回其 solutions
            return cellGroups[index].solutions;
        }

        // 获取当前 CellGroup 的 solutions
        var currentSolutions = cellGroups[index].solutions;

        // 获取剩余 CellGroup 的 solutions（递归调用）
        var mergedNextSolutions = MergeRecursive(cellGroups, index + 1);

        // 合并当前 solutions 和递归结果
        List<int[]> mergedResults = new List<int[]>();

        foreach (var solution1 in currentSolutions)
        {
            foreach (var solution2 in mergedNextSolutions)
            {
                // 创建合并后的 solution
                int[] mergedSolution = new int[solution1.Length + solution2.Length];
                solution1.CopyTo(mergedSolution, 0);
                solution2.CopyTo(mergedSolution, solution1.Length);

                // 添加到结果列表
                mergedResults.Add(mergedSolution);
            }
        }

        return mergedResults;
    }
    //检测 max和min 那就是我们要的情况

    #endregion

    #region PSEQ_UI
    public void ShowS()
    {
        List<CellManager> guessList = AIManager.instance.FindAllWithMinNumber(GameManager.instance.restCellManagers);
        PSEQ.FILTER_S(guessList);
            
        foreach (var cell in GameManager.instance.cellList)
        {
            cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
            if (!cell.isOpen&&cell.PSEQ_S!=0)
            {
                /*FILTER_S(GameManager.instance.restCellManagers);*/
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.gameObject.SetActive(true);
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.text= cell.PSEQ_S.ToString();
            }
        }
    }
    public void CloseS()
    {
        foreach (var cell in GameManager.instance.cellList)
        {
            cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(true);
            if (!cell.isOpen)
            {
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.gameObject.SetActive(false);
            }
            else
            {
                cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
            }
        }

    }
    
    
    public void ShowE()
    {
        List<CellManager> guessList = AIManager.instance.FindAllWithMinNumber(GameManager.instance.restCellManagers);
        PSEQ.FILTER_S(guessList);
            
        foreach (var cell in GameManager.instance.cellList)
        {
            cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
            if (!cell.isOpen&&cell.PSEQ_S!=0)
            {
                /*FILTER_S(GameManager.instance.restCellManagers);*/
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.gameObject.SetActive(true);
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.text= cell.PSEQ_S.ToString();
            }
        }
    }
    public void CloseE()
    {
        foreach (var cell in GameManager.instance.cellList)
        {
            cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(true);
            if (!cell.isOpen)
            {
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.gameObject.SetActive(false);
            }
            else
            {
                cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
            }
        }

    }



    public void ShowQ()
    {
        foreach (var cell in GameManager.instance.cellList)
        {
            cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
            if (!cell.isOpen)
            {
                cell.weight=FILTER_Q(cell);
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.gameObject.SetActive(true);
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.text= cell.weight.ToString();
            }
        }

    }
    public void ShowTargetQ()
    {
        List<CellManager> guessList = AIManager.instance.FindAllWithMinNumber(GameManager.instance.restCellManagers);
        foreach (var cell in GameManager.instance.cellList)
        {
            cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);

        }
        
        foreach (var cell in guessList)
        {
            if (!cell.isOpen)
            {
                cell.weight=FILTER_Q(cell);
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.gameObject.SetActive(true);
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.text= cell.weight.ToString();
            }
        }
        Func<CellManager, float> sortKey= (cell) => -cell.weight;
        guessList = guessList.OrderBy(sortKey).ToList();
        guessList[0].cellModel.GetComponent<SingleCellDisplay>().cellCover.GetComponent<Image>().color=Color.green;
        tempTarget=guessList[0].cellModel;
    }

    GameObject tempTarget;
    public void CloseQ()
    {
        foreach (var cell in GameManager.instance.cellList)
        {
            cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(true);
            if (!cell.isOpen)
            {
                cell.cellModel.GetComponent<SingleCellDisplay>().otherText.gameObject.SetActive(false);
            }
            else
            {
                cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
            }
        }
        tempTarget.GetComponent<SingleCellDisplay>().cellCover.GetComponent<Image>().color=Color.grey;
    }

    #endregion


    //方块的邻居中恰好𝑖i 个地雷的概率
    //计算情报熵log2
    /// <summary>
    /// 我需要准备好所有的相邻格子放进去就会自动生成概率
    /// </summary>
    /// <param name="cells"></param>
   public static List<float>  FILTER_Prob(CellManager targetCell)
   {

       
        List<CellManager> cells = new List<CellManager>();
       //探索四周
       // 遍历周围的八个格子
       
       int x = targetCell.position.Item2;
       int y = targetCell.position.Item1;
       for (int i = -1; i <= 1; i++)
       {
           for (int j = -1; j <= 1; j++)
           {
               // 跳过中心点（cellManager 自身）
               if (i == 0 && j == 0)
               {
                   continue;
               }

               int targetX = x + i;
               int targetY = y + j;

               // 检查是否在有效的网格范围内
               if (targetX >= 0 && targetX < GameManager.instance.cellList.GetLength(0) &&
                   targetY >= 0 && targetY < GameManager.instance.cellList.GetLength(1))
               {
                   // 获取目标格子
                   CellManager target = GameManager.instance.cellList[targetY, targetX];

                   // 检查目标格子是否符合条件
                   if (!target.isOpen)
                   {
                       //不大开的放进去
                       cells.Add(target);
                   }
               }
           }
       }
        
       if (targetCell.position.Item2==2&&targetCell.position.Item1==1)
       {
           foreach (var target in cells)
           {
               /*
               Debug.Log("坐标是"+target.position.Item2+" "+ target.position.Item1+"概率是"+target.Probobability);
                */
           }
       }
        
        //首先，周围有几个？
        int surrondCell=cells.Count;

        Dictionary<int, List<int[]>> dict = GenerateLists(surrondCell);
        List<float> probList=new List<float>();
        for (int i = 0; i < surrondCell; i++)
        {
            //这个是大的概率，有i个1的概率
            float allProb=0;
            //现在是一个list，里面是所有包含i个1的list


            for (int j = 0; j < dict[i].Count; j++)
            {
                //这个是每个情况具体的概率
                float tempProb=1;
                for (int k = 0; k < surrondCell; k++)
                {
                    if ( dict[i][j][k]==1)
                    {
                        tempProb *= cells[k].Probobability;
                    }
                    else
                    {
                        tempProb *= (1- cells[k].Probobability);
                    }
                
                }
                tempProb=(float)Math.Round(tempProb, 3);
                allProb += tempProb;

            }

            probList.Add(allProb);
        }


        
        return probList;
    }


    /// <summary>
    /// n,包含n个1的list int[]
    /// </summary>
    /// <param name="n"></param>
    /// <returns></returns>
    static Dictionary<int, List<int[]>> GenerateLists(int n)
    {
        Dictionary<int, List<int[]>> dict = new Dictionary<int, List<int[]>>();
        int totalCombinations = (int)Math.Pow(2, n);

        for (int i = 0; i < totalCombinations; i++)
        {
            int[] binaryArray = ConvertToBinaryArray(i, n);
            int onesCount = binaryArray.Count(x => x == 1);

            if (!dict.ContainsKey(onesCount))
            {
                dict[onesCount] = new List<int[]>();
            }
            dict[onesCount].Add(binaryArray);
        }

        return dict;
    }

    static int[] ConvertToBinaryArray(int num, int length)
    {
        int[] binaryArray = new int[length];
        for (int i = 0; i < length; i++)
        {
            binaryArray[length - i - 1] = (num >> i) & 1;
        }
        return binaryArray;
    }
    
    #region UI
    public static int[] ConvertIndex(int indexAll, List<CellGroup> cellGroups)
    {
        int groupCount = cellGroups.Count;
        int[] indices = new int[groupCount];

        // 首先，获取每个 CellGroup 的基数（solutions 长度）
        int[] radixes = new int[groupCount];
        for (int i = 0; i < groupCount; i++)
        {
            radixes[i] = cellGroups[i].solutions.Count;
        }

        // 计算每个位置的基数乘积，用于除法和取模
        Debug.Log(groupCount);
        int[] radixProducts = new int[groupCount];
        Debug.Log(radixProducts.Count());
        radixProducts[groupCount - 1] = 1;
        for (int i = groupCount - 2; i >= 0; i--)
        {
            radixProducts[i] = radixes[i + 1] * radixProducts[i + 1];
        }

        // 开始计算每个索引
        for (int i = 0; i < groupCount; i++)
        {
            indices[i] = indexAll / radixProducts[i];
            indexAll = indexAll % radixProducts[i];
        }

        return indices;
    }
    
    int index = 0;
    public void ShowMineUI(int solutionIndex,CellGroup cellGroup)
    {
        for (int i = 0; i < cellGroup.cellManagers.Count(); i++)
        {
            Debug.Log("isBoom?"+cellGroup.solutions[solutionIndex][i]);
            CellManager cellManager=cellGroup.cellManagers[i];
            if (cellGroup.solutions[solutionIndex][i]==1)
            {
                cellManager.cellModel.GetComponent<SingleCellDisplay>().cellBomb.SetActive(true);
                cellManager.cellModel.GetComponent<SingleCellDisplay>().cellCover.SetActive(false);
            }
            else
            {
                cellManager.cellModel.GetComponent<SingleCellDisplay>().cellBomb.SetActive(false);
                cellManager.cellModel.GetComponent<SingleCellDisplay>().cellCover.SetActive(true);
            }

        }

    }

    public void StartShowMine()
    {
        foreach (var cell in GameManager.instance.cellList)
        {
            cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
            if (cell.isSurrondCell)
            {
                cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(true);
            }
        }
        
        index = 0;
        int[] indexList= ConvertIndex(index, AIManager.instance.allSurrondCellGroups);
        for (int i = 0; i < AIManager.instance.allSurrondCellGroups.Count(); i++)
        {
            
            ShowMineUI(indexList[i],AIManager.instance.allSurrondCellGroups[i]);
        }

    }
    public void ShowNextMineUI()
    {
        index++;
        int indexMax = 1;
        foreach (var cellGroup in AIManager.instance.allSurrondCellGroups)
        {
            indexMax *= cellGroup.solutions.Count;
        }
        if (index>=indexMax)
        {
            index = 0;
        }

        int[] indexList= ConvertIndex(index, AIManager.instance.allSurrondCellGroups);
        for (int i = 0; i < AIManager.instance.allSurrondCellGroups.Count(); i++)
        {

            ShowMineUI(indexList[i],AIManager.instance.allSurrondCellGroups[i]);
        }
    }

    public void CloseMine()
    {
        index = 0;
        foreach (var cellManagerGroup in AIManager.instance.allSurrondCellGroups)
        {
            foreach (var cellManager in cellManagerGroup.cellManagers)
            {
                cellManager.cellModel.GetComponent<SingleCellDisplay>().cellCover.SetActive(true);
                if (cellManager.isBoom)
                {

                    cellManager.cellModel.GetComponent<SingleCellDisplay>().cellBomb.SetActive(true);
                }
                else
                {
                    cellManager.cellModel.GetComponent<SingleCellDisplay>().cellBomb.SetActive(false);
                }
            }
        }
        
        foreach (var cell in GameManager.instance.cellList)
        {
            cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(true);
            if (!cell.isOpen)
            {

            }
            else
            {
                cell.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
            }
        }
        
    }

    #endregion
    /*public void CheckSolutions()
    {

        foreach (var solution in solutions)
        {
            //准备数值
            allSurrondCellManager = AIManager.instance.allSurrondCellManagerGroups;
            //赋值
            for (int i = 0; i < AIManager.instance.allSurrondCellManagerGroups.Count; i++)
            {
                allSurrondCellManager[i].tempNum=solution[i];
            }
            
        }
    }*/
    

   


    public void CheckAllPairs(List<CellManager> cellList)
    {
        foreach (var VARIABLE in cellList)
        {
            VARIABLE.nearbyCell.Clear();
            
        }
        for (int i = 0; i < cellList.Count; i++)
        {
            for (int j = i + 1; j < cellList.Count; j++)
            {
                if (CheckNearBy(cellList[i], cellList[j]))
                {
                    Console.WriteLine($"Cell {i} and Cell {j} are adjacent.");
                    cellList[i].nearbyCell.Add(cellList[j]);
                    cellList[j].nearbyCell.Add(cellList[i]);
                }
                else
                {

                }
            }
        }
    }

    /*public void Init()
    {
        foreach (var VARIABLE in AIManager.instance.allSurrondCellManagerGroups)
        {
            VARIABLE.nearbyUnknownCell = 0;
        }
    }*/

    public bool CheckNearBy(CellManager cell1, CellManager cell2) 
    {
        // 获取两个格子的x和y坐标
        int x1 = cell1.position.Item1;
        int y1 = cell1.position.Item2;
        int x2 = cell2.position.Item1;
        int y2 = cell2.position.Item2;

        // 判断是否在九宫格范围内
        if (Math.Abs(x1 - x2) <= 1 && Math.Abs(y1 - y2) <= 1)
        {
            return true; // 两个格子是邻近的
        }
        else
        {
            return false; // 两个格子不是邻近的
        }
    }

    public void CheckUnKnownNearby(CellManager cellManager)
    {
        int x = cellManager.position.Item1;
        int y = cellManager.position.Item2;

        // 遍历周围的八个格子
        for (int i = -1; i <= 1; i++)
        {
            for (int j = -1; j <= 1; j++)
            {
                // 跳过中心点（cellManager 自身）
                if (i == 0 && j == 0)
                {
                    continue;
                }

                int targetX = x + i;
                int targetY = y + j;

                // 检查是否在有效的网格范围内
                if (targetX >= 0 && targetX < GameManager.instance.cellList.GetLength(0) &&
                    targetY >= 0 && targetY < GameManager.instance.cellList.GetLength(1))
                {
                    // 获取目标格子
                    CellManager target = GameManager.instance.cellList[targetX, targetY];

                    // 检查目标格子是否符合条件
                    if (!target.isSurrondCell && !target.isOpen)
                    {
                        cellManager.nearbyUnknownCell += 1;
                    }
                }
            }
        }
    }

}
