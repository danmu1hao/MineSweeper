using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellManager
{
    public GameObject cellModel;
    //isBoom=>1
    public bool isBoom;
    public int index;

    public float weight;
    
    /// <summary>
    /// 这个是为了标记周围格子
    /// 我们要把未知格子进行分类的
    /// </summary>
    public bool isSurrondCell;

    private float probobability;
    public float Probobability
    {
        get
        {
            return (float)Math.Round(probobability, 3);
        }
        set
        {
            probobability=value;
        }
    }

    public bool isOpen=false;
    
    public int boomNumber;
    /// <summary>
    /// (y,x)
    /// </summary>
    public Tuple<int, int> position;
    public bool isFlaged;

    public List<CellManager> nearbyCell;
    //0安全，1为雷 用于暂时确定是什么
    public int tempNum;
    //所有可能出现的数字，注意这个数字是周围的雷数
    public List<int> allNearByCellCondition;
    /// <summary>
    /// 这个标识周围的未知格子，注意是未知，不是相邻
    /// </summary>
    public int nearbyUnknownCell=0;
}
