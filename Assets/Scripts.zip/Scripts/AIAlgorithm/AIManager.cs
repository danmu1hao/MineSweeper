using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;
using Debug = UnityEngine.Debug;
using Image = UnityEngine.UI.Image;

public class AIManager : MonoBehaviour
{
    bool debugMode;
    
    // 方向数组，表示上下左右以及对角线的8个方向
    private int[] dx = { -1, 1, 0, 0, -1, -1, 1, 1 };
    private int[] dy = { 0, 0, -1, 1, -1, 1, -1, 1 };

    
    public static AIManager instance;

    public CellManager[,] cellList;
    public List<CellManager> safeCell;
    /*public List<CellManager> questionCell;*/

    public List<Tuple<List<CellManager>, int>> safeCellWithEquation;
    public List<CellManager> surroundCell;


    public int allCellNum;
    public int maxMine;


    public int row;
    public int column;

    public List<List<CellManager>> openCellList;
    List<CellManager> _surroundCellListTemp;

    public void CalculateAllProb()
    {
        CheckOpen();
        surroundCell = ExploreSurroundings(safeCell);
        ChangeYellow();

        DFSSearch dfsSearchScript = gameObject.GetComponent<DFSSearch>();
        List<List<CellManager>> groupedSafeCells = dfsSearchScript.FindSafeCellGroups();
        foreach (var safeCells in groupedSafeCells)
        {
            safeCellWithEquation = CollectEquation(safeCells);
            gameObject.GetComponent<SolveMineSweeper>().SolveMineSweeperMethod(safeCellWithEquation);
        }

        SetProbUI();
    }

    #region AI全自动

    public float waitTime=1f;
    public int repeatTimes = 100;
    public int repeatrepeatTimes;
    
    List<CellManager> cornerList;
    bool first=true;

    public void StartAICoroutine()
    {
        StartCoroutine(AIAutoPlayAnime());
    }
    
    // 定义协程
    public IEnumerator AIAutoPlayAnime()
    {
        while (true)
        {
            while (!GameManager.instance.GameOver)
            {
                // 每 1 秒执行一次
                AIAuto();

                // 等待 1 秒
                yield return new WaitForSeconds(waitTime);
            }

            if (GameManager.instance.GameOver)
            {
                GameManager.instance.GameStart();
            }
        }
    }
    
    public void StartAI()
    {
        List<string> strList = new List<string>();
        for (int i = 0; i < repeatrepeatTimes; i++)
        {
            // 启动计时器
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            // 输出执行时间，单位为毫秒
            Debug.Log("方法执行时间: " + stopwatch.ElapsedMilliseconds + " 毫秒");
            int times = 0;
            int wins = 0;
            int lose = 0;
            while (times<repeatTimes)
            {
                while (!GameManager.instance.GameOver)
                {
                    // 每 1 秒执行一次
                    AIAuto();
                }

                if (GameManager.instance.youWin==true)
                {
                    wins += 1;
                }
                else
                {
                    lose += 1;
                }
                times += 1;
                if (GameManager.instance.GameOver)
                {
                    GameManager.instance.GameStart();
                }
            }


            strList.Add($"you win {wins} you lose {lose}");

            Debug.Log("you win"+wins+"you lose"+lose);
            stopwatch.Stop();
            // 输出执行时间，单位为毫秒
            Debug.Log("執行時間: " + stopwatch.ElapsedMilliseconds + " 秒");
            strList.Add("執行時間: " + stopwatch.ElapsedMilliseconds + " 秒");
        }

        WriteListToTxt(strList,"testData.txt");
    }
    void WriteListToTxt(List<string> stringList, string fileName)
    {
        string path = Application.dataPath + "/" + fileName;

        // 使用 StreamWriter 将 List<string> 写入文件
        using (StreamWriter writer = new StreamWriter(path, false))
        {
            foreach (string line in stringList)
            {
                writer.WriteLine(line);
            }
        }
    }
    
    public void AIAuto()
    {

        if (first)
        {
            FirstMove();
            cornerList=new List<CellManager>(){cellList[0,0],cellList[row-1,0],cellList[row-1,column-1],cellList[0,column-1]};
            first = false;
        }

        if (!AFNOrAMN())
        {
            AIGuess();
        }

        GameManager.instance.CheckGameFinished();
    }
    
    //afn...
    public bool AFNOrAMN()
    {
        bool changed = false;
        foreach (var cellManager in surroundCell)
        {
            if (cellManager.Probobability<=0.0001f)
            {
                GameManager.instance.ExploreEvent(cellManager.cellModel);
                changed = true;
            }
            else if(cellManager.Probobability>0.9999f)
            {
                if (!cellManager.isFlaged)
                {
                    GameManager.instance. SetFlage(cellManager.cellModel);
                    changed = true;
                }
            }
        }
        return  changed;
    }


    public void FirstMove()
    {
        GameManager.instance.ExploreEvent(cellList[0,0].cellModel);
    }
    //AIGuess
    public void AIGuess()
    {
        //开始猜测
        foreach (var VARIABLE in GameManager.instance.restCellManagers)
        {
            /*Debug.LogError("坐标是"+VARIABLE.position.Item2+"y是"+VARIABLE.position.Item1+"权重是"+VARIABLE.Probobability);*/
        }
        List<CellManager> guessList = FindAllWithMinNumber(GameManager.instance.restCellManagers);

        foreach (var guessCell in guessList)
        {
            guessCell.weight = PSEQ.FILTER_Q(guessCell);
            /*
            Debug.LogError("重量是"+guessCell.weight+"坐标是"+guessCell.position.Item2+"y是"+guessCell.position.Item1+"权重是"+guessCell.Probobability);
        */
        }


        /*Debug.LogError(guessList.Count);*/
        List<CellManager> guessListNew = FindAllWithMinNumber(guessList, x => -x.weight);

        if (guessListNew.Count>0)
        {
            GameManager.instance.ExploreEvent(guessListNew[0].cellModel);
        }
        else
        {
            UnityEngine.Debug.LogError(guessListNew.Count);
        }
        return;
        /*Debug.Log("Start Guess");*/
        /*foreach (var VARIABLE in cornerList)
        {
            if (guessList.Contains(VARIABLE))
            {
                /*Debug.Log("corner");#1#
                GameManager.instance.ExploreEvent(VARIABLE.cellModel);
                return;
            }
        }

        foreach (var VARIABLE in GameManager.instance.restCellManagers)
        {
            if (GetSurroundingCount(VARIABLE.position.Item1,VARIABLE.position.Item2) == 5)
            {
                /*Debug.Log("edge");#1#
                GameManager.instance.ExploreEvent(VARIABLE.cellModel);
                return;
            }
        }
        foreach (var VARIABLE in GameManager.instance.restCellManagers)
        {
            if (GetSurroundingCount(VARIABLE.position.Item1,VARIABLE.position.Item2) == 8)
            {
                /*Debug.Log("center");#1#
                GameManager.instance.ExploreEvent(VARIABLE.cellModel);
                return;
            }
        }*/
    }
    // 查找所有具有最小 number 的对象
    public List<CellManager> FindAllWithMinNumber(List<CellManager> classList)
    {
        classList=classList.OrderBy(x => x.Probobability).ToList();
        if (classList == null || classList.Count == 0) return new List<CellManager>();

        // 找到最小的 number
        float minNumber = classList[0].Probobability;
        foreach (var obj in classList)
        {
            if (obj.Probobability < minNumber)
            {
                minNumber = obj.Probobability;
            }
        }

        List<CellManager> result = new List<CellManager>();
        foreach (var obj in classList)
        {
            if ( Mathf.Abs(obj.Probobability - minNumber) <0.0001f )
            {
                result.Add(obj);
            }
        }

        return result;
    }
    List<CellManager> FindAllWithMinNumber(List<CellManager> classList, Func<CellManager, float> sortKey)
    {
        if (classList == null || classList.Count == 0) return new List<CellManager>();

        // 使用传入的 sortKey 排序
        classList = classList.OrderBy(sortKey).ToList();

        foreach (var VARIABLE in classList)
        {
            Debug.Log(VARIABLE.weight);
        }
        // 找到最小的值
        float minNumber = sortKey(classList[0]);

        List<CellManager> result = new List<CellManager>();
        foreach (var obj in classList)
        {
            if (Mathf.Abs(sortKey(obj) - minNumber) < 0.0001f)
            {
                result.Add(obj);
            }
        }

        return result;
    }

    #endregion


    
    void Awake()
    {
        instance = this;
        safeCell = new List<CellManager>();
        surroundCell = new List<CellManager>();
        safeCellWithEquation = new List<Tuple<List<CellManager>, int>>();
    }

    public void Init()
    {
        safeCell.Clear();
        safeCellWithEquation.Clear();
        surroundCell.Clear();
        first = true;
        
        
        row = GameManager.instance.row;
        column=GameManager.instance.column;
        cellList = GameManager.instance.cellList;

    }

    void Start()
    {


        row = GameManager.instance.row;
        column = GameManager.instance.column;
        cellList = GameManager.instance.cellList;

        CalculateAllProb();
    }
    




    public void SetProbUI()
    {
        foreach (var cellManager in cellList)
        {
            cellManager.isSurrondCell = false;

            if (cellManager.isOpen)
            {
                cellManager.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
            }
        }

        var otherProb = OtherProb();

        foreach (var cellManager in surroundCell)
        {
            cellManager.cellModel.GetComponent<SingleCellDisplay>().prob.GetComponent<TextMeshProUGUI>().text =
                (100 * cellManager.Probobability).ToString("F3") + "%";
            cellManager.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(true);
            cellManager.isSurrondCell = true;
            if (cellManager.Probobability < 0.01f)
            {
                cellManager.cellModel.GetComponent<SingleCellDisplay>().cellCover.gameObject.GetComponent<Image>()
                    .color = Color.green;   

            }
            else if (cellManager.Probobability > 0.9999f)
            {
                cellManager.cellModel.GetComponent<SingleCellDisplay>().cellCover.gameObject.GetComponent<Image>()
                    .color = Color.red;
            }
        }


        foreach (var cellManager in (GameManager.instance.cellList))
        {
            if (!cellManager.isOpen)
            {
                if (!cellManager.isSurrondCell)
                {
                    cellManager.Probobability = otherProb;
                    cellManager.cellModel.GetComponent<SingleCellDisplay>().prob.GetComponent<TextMeshProUGUI>().text =
                        (100*otherProb).ToString("F3") + "%";
                    cellManager.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(true);
                }

                    

            }

        }

        /*foreach (var VARIABLE in surroundCell)
        {
            Debug.Log(VARIABLE.Probobability);
        }*/
    }

    float OtherProb()
    {
        float otherProb;
        int allCell = cellList.GetLength(0) * cellList.GetLength(1);
        int otherNum = allCell - safeCell.Count - surroundCell.Count;

        if (debugMode)
        {
            Debug.Log(allCell + "减去" + safeCell.Count + "  " + surroundCell.Count + "那么，还剩下这么多个格子。。。。" + otherNum);
        }
        float restMine;
        Dictionary<int, int> oneCountSummary = gameObject.GetComponent<SolveMineSweeper>().oneCountSummary;
        int conditionNum = 0;
        foreach (var VARIABLE in oneCountSummary)
        {
            conditionNum += VARIABLE.Value;
        }

        if (debugMode)
        {
            Debug.Log("一共有多少种可能呢？" + conditionNum);
        }
        //一共有多少种可能呢？
        float expectation = 0;

        // 输出统计结果
        foreach (var pair in oneCountSummary)
        {
            if (debugMode)
            {
                Debug.Log(pair.Key + " 个 1 出现了 " + pair.Value + " 次");
            }
        }

        foreach (var VARIABLE in oneCountSummary)
        {
            if (debugMode)
            {
                Debug.Log(VARIABLE.Key * ((float)VARIABLE.Value / conditionNum));
                Debug.Log("那么，已知区域的雷的期望为。。" + expectation);
            }
            expectation += VARIABLE.Key * ((float)VARIABLE.Value / conditionNum);
        }


        restMine = GameManager.instance.mineNumber - expectation;
        otherProb = restMine / otherNum;
        otherProb *= 100;
        if (debugMode)
        {
            Debug.Log("那么，已知区域的雷的期望为。。" + expectation);
            Debug.Log("所以这就是概率了" + otherProb);
        }
        return otherProb*0.01f;
    }

    /*
    public void HideProb()
    {
        foreach (var cellManager in (GameManager.instance.cellList))
        {
            cellManager.cellModel.GetComponent<SingleCellDisplay>().prob.SetActive(false);
        }
    }
    */

    /// <summary>
    /// 第一个是行 第二个是列3,5,8
    /// </summary>
    /// <returns></returns>
    int GetSurroundingCount(int x, int y)
    {
        // 矩阵的四个角
        if ((y == 0 && x == 0) || (y == 0 && x == column - 1) || (y == row - 1 && x == 0) ||
            (y == row - 1 && x == column - 1))
        {
            return 3;
        }

        // 矩阵的四条边（但不包括角）
        if (y == 0 || y == row - 1 || x == 0 || x == column - 1)
        {
            return 5;
        }

        // 矩阵的中间
        return 8;
    }

    // Start is called before the first frame update


    public void CheckOpen()
    {
        safeCell.Clear();  // 清空 safeCell 列表
        int rows = cellList.GetLength(0);
        int cols = cellList.GetLength(1);

        // 遍历所有 cell
        foreach (var cell in cellList)
        {
            if (cell.isOpen && HasUnopenedNeighbor(cell))
            {
                safeCell.Add(cell);  // 如果四周存在未打开的单元格，添加到 safeCell
            }
        }
    }

    // 检查当前 cell 四周是否存在未打开的单元格
    private bool HasUnopenedNeighbor(CellManager cell)
    {
        int x = cell.position.Item1;  // 当前 cell 的 x 坐标
        int y = cell.position.Item2;  // 当前 cell 的 y 坐标
        int rows = cellList.GetLength(0);
        int cols = cellList.GetLength(1);

        // 遍历周围8个方向
        for (int i = 0; i < 8; i++)
        {
            int newX = x + dx[i];
            int newY = y + dy[i];

            // 确保坐标在边界内
            if (newX >= 0 && newX < rows && newY >= 0 && newY < cols)
            {
                // 如果周围存在未打开的 cell (isOpen=false)，返回 true
                if (!cellList[newX, newY].isOpen)
                {
                    return true;
                }
            }
        }

        // 如果四周全部是 isOpen=true，则返回 false
        return false;
    }

    
    
    //要修正
    public List<CellManager>  ExploreSurroundings( List<CellManager> safeCell)
    {
        _surroundCellListTemp = new List<CellManager>();
        // 遍历所有safeCell中的cell
        foreach (var safe in safeCell)
        {
            int x = safe.position.Item1; // 当前cell的x坐标
            int y = safe.position.Item2;

            // 遍历周围8个方向
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    // 跳过自身
                    if (i == 0 && j == 0)
                        continue;

                    int newX = x + i;
                    int newY = y + j;

                    // 确保坐标没有超出边界
                    if (newX >= 0 && newX < cellList.GetLength(0) && newY >= 0 && newY < cellList.GetLength(1))
                    {
                        var surroundingCell = cellList[newX, newY];

                        // 检查是否是未打开的cell
                        if (!surroundingCell.isOpen)
                        {
                            if (!_surroundCellListTemp.Contains(surroundingCell))
                            {
                                _surroundCellListTemp.Add(surroundingCell);
                            }
                        }
                    }
                }
            }
        }

        return _surroundCellListTemp;
    }


    public void ChangeYellow()
    {
        foreach (var singleCellManager in surroundCell)
        {
            singleCellManager.cellModel.GetComponent<SingleCellDisplay>().cellCover.gameObject.GetComponent<Image>()
                .color = Color.yellow;
        }
    }

    public List<Tuple<List<CellManager>, int>> CollectEquation(List<CellManager> safeCellListTemp)
    {
        safeCellWithEquation.Clear(); // 清空 surroundCell 列表

        // 遍历所有 safeCell 中的 cell
        foreach (var safe in safeCellListTemp)
        {
            int x = safe.position.Item1; // 当前 cell 的 x 坐标
            int y = safe.position.Item2;

            List<CellManager> cellManagersTemp = new List<CellManager>();

            // 遍历周围 8 个方向
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    // 跳过自身
                    if (i == 0 && j == 0)
                        continue;
                    int newX = x + i;
                    int newY = y + j;

                    
                    // 确保坐标没有超出边界
                    if (newX >= 0 && newX < cellList.GetLength(0) && newY >= 0 && newY < cellList.GetLength(1))
                    {
                        var surroundingCell = cellList[newX, newY];

                        // 检查是否是未打开的 cell
                        if (!surroundingCell.isOpen)
                        {
                            cellManagersTemp.Add(surroundingCell);
                        }

                    }
                }
            }

            Tuple<List<CellManager>, int> tuple = new Tuple<List<CellManager>, int>(cellManagersTemp, safe.boomNumber);
            /*Debug.Log(safe.boomNumber);*/
            safeCellWithEquation.Add(tuple); // 将未打开的 cell 添加到 surroundCell
        }

        return safeCellWithEquation;

    }




    int index=0;
    public void ShowCondition()
    {
        for (int i = 0; i < SolveMineSweeper.allSurrondCellManager.Count; i++)
        {
            
        }
    }


}
