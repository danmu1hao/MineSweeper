using UnityEngine;

public class NormalizeMatrix : MonoBehaviour
{
    void Start()
    {
        // 示例输入矩阵
        int[,] matrix = {
            { 1, 1, 1 ,3},
            { 2, 1, 1 ,1},
            { 2, 5, 1 ,1}
        };

        // 进行高斯消元
        GaussianElimination(matrix);

        // 输出消元后的矩阵
        Debug.Log("阶梯型矩阵：");
        PrintMatrix(matrix);
    }

    // 高斯消元算法（只允许乘法和减法）
    void GaussianElimination(int[,] matrix)
    {
        int rows = matrix.GetLength(0);
        int cols = matrix.GetLength(1);

        for (int i = 0; i < Mathf.Min(rows, cols); i++)
        {
            // 如果主元为0，则向下交换行
            if (matrix[i, i] == 0)
            {
                for (int k = i + 1; k < rows; k++)
                {
                    if (matrix[k, i] != 0)
                    {
                        SwapRows(matrix, i, k);
                        break;
                    }
                }
            }

            // 消去主元下方的元素，不进行归一化
            for (int k = i + 1; k < rows; k++)
            {
                if (matrix[k, i] != 0) // 确保当前行需要消去
                {
                    int factor = matrix[k, i] / matrix[i, i];
                    for (int j = i; j < cols; j++)
                    {
                        matrix[k, j] = matrix[k, j] - factor * matrix[i, j];
                    }
                }
            }
        }
    }

    // 行交换
    void SwapRows(int[,] matrix, int row1, int row2)
    {
        int cols = matrix.GetLength(1);
        for (int i = 0; i < cols; i++)
        {
            int temp = matrix[row1, i];
            matrix[row1, i] = matrix[row2, i];
            matrix[row2, i] = temp;
        }
    }

    // 输出矩阵
    void PrintMatrix(int[,] matrix)
    {
        int rows = matrix.GetLength(0);
        int cols = matrix.GetLength(1);
        for (int i = 0; i < rows; i++)
        {
            string row = "";  // 用于拼接每行的元素
            for (int j = 0; j < cols; j++)
            {
                row += $"{matrix[i, j]} ";
            }
            Debug.Log(row);  // 输出整行
        }
    }
}
