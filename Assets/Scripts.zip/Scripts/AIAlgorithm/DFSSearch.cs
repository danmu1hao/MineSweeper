using System.Collections.Generic;
using UnityEngine;

//负责分区，然后合并有相同元素的list
public class DFSSearch : MonoBehaviour
{
    public CellManager[,] cellList;

    // 用来存储所有分组的列表
    public List<List<CellManager>> groupedSafeCells = new List<List<CellManager>>();
    public List<List<CellManager>> groupedSurroundCells = new List<List<CellManager>>();
    // 方向数组，表示上下左右以及对角线的8个方向
    private int[] dx = { -1, 1, 0, 0, -1, -1, 1, 1 };
    private int[] dy = { 0, 0, -1, 1, -1, 1, -1, 1 };

    void Start()
    {
        groupedSafeCells=new List<List<CellManager>>();
        groupedSurroundCells = new List<List<CellManager>>();
        // 初始化并调用分组方法
        /*FindOpenCellGroups();*/
    }

    // 主方法，遍历矩阵并找到所有相邻的 isOpen=true 的 group
    public List<List<CellManager>> FindSafeCellGroups()
    {
        groupedSafeCells = new List<List<CellManager>>();
        groupedSurroundCells = new List<List<CellManager>>();
        cellList = GameManager.instance.cellList;
        
        int rows = cellList.GetLength(0);
        int cols = cellList.GetLength(1);
        bool[,] visited = new bool[rows, cols];  // 记录访问过的元素

        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                // 如果当前单元格未访问过且是 isOpen=true
                if (cellList[i, j].isOpen && !visited[i, j])
                {
                    List<CellManager> group = new List<CellManager>();
                    DFS(i, j, visited, group);  // 使用 DFS 查找相邻的 isOpen 单元格
                    groupedSafeCells.Add(group);    // 将找到的 group 添加到列表中
                }
            }
        }

        // 输出结果
        foreach (var group in groupedSafeCells)
        {
            string groupInfo = "Group: ";
            foreach (var cell in group)
            {
                groupInfo += $"({cell.position.Item2}, {cell.position.Item1}) ";  // 假设 position 是一个 Tuple<int, int> 类型
            }
            /*Debug.Log(groupInfo);*/
        }


        groupedSafeCells=MergeAllSafeCellGroups(groupedSafeCells);

        // 输出结果
        foreach (var group in groupedSafeCells)
        {
            string groupInfo = "Group: ";
            foreach (var cell in group)
            {
                groupInfo += $"({cell.position.Item2}, {cell.position.Item1}) ";  // 假设 position 是一个 Tuple<int, int> 类型
            }
            /*Debug.Log(groupInfo);*/
        }

        return groupedSafeCells;

        /*
        foreach (var safecells in groupedSafeCells)
        {
            groupedSurroundCells.Add( AIManager.instance.ExploreSurroundings(safecells));
        }
        */


        /*// 输出结果
        foreach (var group in groupedSurroundCells)
        {
            string groupInfo = "Group: ";
            foreach (var cell in group)
            {
                groupInfo += $"({cell.position.Item2}, {cell.position.Item1}) ";  // 假设 position 是一个 Tuple<int, int> 类型
            }
            Debug.Log(groupInfo);
        }


        groupedSurroundCells= MergeRelatedLists(groupedSurroundCells);

        // 输出结果
        foreach (var group in groupedSurroundCells)
        {
            string groupInfo = "Group: ";
            foreach (var cell in group)
            {
                groupInfo += $"({cell.position.Item2}, {cell.position.Item1}) ";  // 假设 position 是一个 Tuple<int, int> 类型
            }
            Debug.Log(groupInfo);
        }*/
    }

    // 深度优先搜索 (DFS) 方法
    void DFS(int x, int y, bool[,] visited, List<CellManager> group)
    {
        visited[x, y] = true;
        if (HasUnopenedNeighbor(cellList[x, y]))
        {
            group.Add(cellList[x, y]);  // 将当前单元格添加到 group 中
        }

        int rows = cellList.GetLength(0);
        int cols = cellList.GetLength(1);

        // 遍历当前单元格的周围8个方向
        for (int i = 0; i < 8; i++)
        {
            int newX = x + dx[i];
            int newY = y + dy[i];

            // 检查边界并且确保下一个单元格是 isOpen=true 且未访问过
            if (newX >= 0 && newX < rows && newY >= 0 && newY < cols && cellList[newX, newY].isOpen && !visited[newX, newY])
            {
                DFS(newX, newY, visited, group);
            }
        }
    }
    // 检查当前 cell 四周是否存在未打开的单元格
    private bool HasUnopenedNeighbor(CellManager cell)
    {
        int x = cell.position.Item1;  // 当前 cell 的 x 坐标
        int y = cell.position.Item2;  // 当前 cell 的 y 坐标
        int rows = cellList.GetLength(0);
        int cols = cellList.GetLength(1);

        // 遍历周围8个方向
        for (int i = 0; i < 8; i++)
        {
            int newX = x + dx[i];
            int newY = y + dy[i];

            // 确保坐标在边界内
            if (newX >= 0 && newX < rows && newY >= 0 && newY < cols)
            {
                // 如果周围存在未打开的 cell (isOpen=false)，返回 true
                if (!cellList[newX, newY].isOpen)
                {
                    return true;
                }
            }
        }

        // 如果四周全部是 isOpen=true，则返回 false
        return false;
    }

    // 查找有关联的列表索引
    public List<int[]> FindRelatedLists(List<List<CellManager>> groupedCells)
    {
        List<int[]> relatedIndices = new List<int[]>();

        // 遍历所有的列表组合
        for (int i = 0; i < groupedCells.Count; i++)
        {
            for (int j = i + 1; j < groupedCells.Count; j++)
            {
                if (HasCommonElement(groupedCells[i], groupedCells[j]))
                {
                    relatedIndices.Add(new int[] { i, j });  // 如果有共同元素，记录索引
                }
            }
        }

        return relatedIndices;
    }

    // 判断两个列表是否有共同的元素
    private bool HasCommonElement(List<CellManager> list1, List<CellManager> list2)
    {
        // 遍历 list1 的每个元素，检查是否在 list2 中
        foreach (var cell in list1)
        {
            if (list2.Contains(cell))
            {
                return true;  // 找到共同元素，返回 true
            }
        }

        return false;  // 没有找到共同元素
    }

    public List<List<CellManager>>  MergeRelatedLists(List<List<CellManager>> cellGroup)
    {
        bool hasChange = true;

        // 持续遍历，直到没有新的合并
        while (hasChange)
        {
            hasChange = false;

            // 使用嵌套循环检查每两个列表之间的关系
            for (int i = 0; i < cellGroup.Count; i++)
            {
                for (int j = i + 1; j < cellGroup.Count; j++)
                {
                    // 检查两个列表是否有共同元素
                    if (HasCommonElement(cellGroup[i], cellGroup[j]))
                    {
                        // 合并列表
                        List<CellManager> mergedList = MergeIfCommonElement(cellGroup[i], cellGroup[j]);

                        // 移除两个列表
                        cellGroup.RemoveAt(j); // 先移除 j 列表
                        cellGroup.RemoveAt(i); // 再移除 i 列表（i 位于 j 之前）

                        // 添加合并后的列表
                        cellGroup.Add(mergedList);

                        // 标记发生了变化
                        hasChange = true;

                        // 立即终止当前的遍历，并重新开始
                        goto EndOfOuterLoop;
                    }
                }
            }
            EndOfOuterLoop: ; // 标签，用于提前退出嵌套循环
            
        }

        return cellGroup;
    }


    // 方法：如果两个List<CellManager>有相同元素，合并并返回合并后的列表；否则返回null
    public List<CellManager> MergeIfCommonElement(List<CellManager> list1, List<CellManager> list2)
        {
            // 判断是否有相同元素
            foreach (var cell in list1)
            {
                if (list2.Contains(cell))
                {
                    // 如果找到相同的元素，合并两个列表并返回
                    List<CellManager> mergedList = new List<CellManager>(list1);
                    foreach (var cellInList2 in list2)
                    {
                        if (!mergedList.Contains(cellInList2)) // 避免重复
                        {
                            mergedList.Add(cellInList2);
                        }
                    }

                    return mergedList; // 返回合并后的列表
                }
            }

            // 如果没有相同元素，返回null
            return null;
        }
    
    
        // 主方法：接收一个输入的 groupedSafeCells 列表，合并后返回合并的列表
    public List<List<CellManager>> MergeAllSafeCellGroups(List<List<CellManager>> inputGroupedSafeCells)
    {
        List<List<CellManager>> mergedSafeCells = new List<List<CellManager>>(inputGroupedSafeCells); // 创建合并后的列表副本
        bool merged = true;

        // 当存在可以合并的列表时，继续合并
        while (merged)
        {
            merged = false;

            // 遍历 mergedSafeCells 中的所有列表，尝试合并
            for (int i = 0; i < mergedSafeCells.Count; i++)
            {
                for (int j = i + 1; j < mergedSafeCells.Count; j++)
                {
                    if (AreListsAdjacent(mergedSafeCells[i], mergedSafeCells[j]))
                    {
                        // 合并两个列表
                        List<CellManager> mergedList = new List<CellManager>(mergedSafeCells[i]);
                        foreach (var cell in mergedSafeCells[j])
                        {
                            if (!mergedList.Contains(cell))
                            {
                                mergedList.Add(cell);
                            }
                        }

                        // 移除原来的两个列表，添加合并后的列表
                        mergedSafeCells.RemoveAt(j); // 先删除后面的索引
                        mergedSafeCells.RemoveAt(i); // 再删除前面的索引
                        mergedSafeCells.Add(mergedList); // 添加合并后的列表

                        merged = true; // 设置标记，表示进行了合并
                        /*Debug.Log("合并");*/
                        // 重新开始合并，确保合并的列表也被检测
                        break;
                    }
                }

                if (merged)
                {
                    break; // 进行了一次合并后，重新遍历列表
                }
            }
        }

        return mergedSafeCells; // 返回合并后的列表
    }

    // 判断两个列表是否有满足邻近条件的元素
    private bool AreListsAdjacent(List<CellManager> list1, List<CellManager> list2)
    {
        foreach (var cell1 in list1)
        {
            foreach (var cell2 in list2)
            {
                if (IsAdjacent(cell1, cell2))
                {
                    return true; // 如果找到邻近元素，返回 true
                }
            }
        }

        return false; // 如果没有找到邻近元素，返回 false
    }

    // 判断两个 CellManager 是否满足邻近条件
    private bool IsAdjacent(CellManager cell1, CellManager cell2)
    {
        int x1 = cell1.position.Item1;
        int y1 = cell1.position.Item2;
        int x2 = cell2.position.Item1;
        int y2 = cell2.position.Item2;

        // 判断 x 和 y 坐标的绝对值差是否小于等于 2
        return Mathf.Abs(x1 - x2) <= 2 && Mathf.Abs(y1 - y2) <= 2;
    }
    
}

